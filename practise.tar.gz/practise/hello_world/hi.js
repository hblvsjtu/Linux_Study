'use strict'
var addon = require('/home/lvhongbin/Desktop/hello_world/build/Release/hello.node');
exports.hello = function() { return addon.hello() }
