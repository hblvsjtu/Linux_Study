var hello = require("./hi.js");
console.log(hello.hello());
