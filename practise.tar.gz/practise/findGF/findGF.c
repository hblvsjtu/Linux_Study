/* ***************************************************************
 *
 * * Filename: FindGF.c
 *
 * * Description:linking and compiling test
 *
 * * Version: 1.0
 *
 * * Created: 2018/05/28
 *
 * * Revision: none
 *
 * * Compiler: gcc
 *
 * * Author: Lv Hongbin
 *
 * * Company: Shanghai JiaoTong Univerity
 *
 * * **************************************************************/

#include<stdio.h>
int main(void) {
	printf("Let's look for a girl\n");
	fight();
}
