/* ***************************************************************
 *
 * * Filename: Fight.c
 *
 * * Description:linking and compiling test
 *
 * * Version: 1.0
 *
 * * Created: 2018/05/28
 *
 * * Revision: none
 *
 * * Compiler: gcc
 *
 * * Author: Lv Hongbin
 *
 * * Company: Shanghai JiaoTong Univerity
 *
 * * **************************************************************/

#include<stdio.h>
void fight(void) {
	printf("I'm learning C programming language! \n");
	printf("I'm earning money! \n");
	printf("I'm keeping fit! \n");
}
